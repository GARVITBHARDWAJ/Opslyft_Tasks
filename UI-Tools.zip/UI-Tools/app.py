import os
from flask import Flask, request, Response, g
from config import logger
import json
from src.routes.reports import report_handler
from src.routes.alerts import alert_handler
from src.routes.home import home_handler
from src.routes.SettingPageBackendR import settingPage
from flask_cors import CORS
from src.routes.alerts_manage import alert_manager
from src.modules.alerts.authentication import validate_login

app = Flask(__name__)
CORS(app)

#UPLOAD_FOLDER = 'gcp_jsons'
#app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

#if not os.path.exists(UPLOAD_FOLDER):
#    os.makedirs(UPLOAD_FOLDER)
app.register_blueprint(report_handler)
app.register_blueprint(alert_handler)
app.register_blueprint(alert_manager)
app.register_blueprint(home_handler)
app.register_blueprint(settingPage)
if __name__ == "__main__":
    app.run(port = 5002, threaded=True)
