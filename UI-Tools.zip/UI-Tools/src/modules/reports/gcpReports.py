import json
import requests
import boto3
import traceback
from flask import Response
from config import logger,gcpDetailsTable,mailUrl
from src.modules.db import DB
from boto3.dynamodb.conditions import Key
import psycopg2
from credentialsPost import postgreCreds

def deployConfig(config,primaryEmail):
    tableName = 'gcp-configs'
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(tableName)
    try:
        items = table.get_item(Key={"primaryEmail": primaryEmail})['Item']['config']
        period = config[0]['period']
        if period not in items:
            logger.info("not in error")
            items[f"{period}"] = []
        if period == "Daily":
            for item in items[period]:
                if config[0]['name'] == item['name']:
                    return "Entry already exists", 409
            items['Daily'].append(config[0])
        elif period == "Weekly":
            for item in items[period]:
                if config[0]['name'] == item['name']:
                    return "Entry already exists", 409
            items['Weekly'].append(config[0])
        elif period == "Monthly":
            for item in items[period]:
                if config[0]['name'] == item['name']:
                    return "Entry already exists", 409
            items["Monthly"].append(config[0])        

        update_expressions = ['SET #config = :config']
        expression_attribute_names = {
            '#config': 'config'
        }
        expression_attribute_values = {
            ':config': items
        }
        
        logger.info('Updating Entry in DynamoDB')
        table.update_item(
            Key={
                'primaryEmail': primaryEmail
            },
            UpdateExpression=', '.join(update_expressions),
            ExpressionAttributeNames=expression_attribute_names,
            ExpressionAttributeValues=expression_attribute_values,
        )

        logger.info('Updated Entry Successfully')
        return "Updated Successfully", 200

    except KeyError as e:
        logger.info('Entry does not exists')
        item = {
            'primaryEmail': primaryEmail,
            'config': [config]
        }

        logger.info('Creating new entry')
        table.put_item(Item=item)

        logger.info('Created Entry successfully')
        return "Created Entry Successfully", 200

    except Exception as e:
        logger.error(str(traceback.format_exc()))
        return "Error Updating", 500


def listConfig(primaryEmail):
    tableName = 'gcp-configs'
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(tableName)
    response = list()
    try:
        logger.info('Fetching Table From DynamoDB')
        items = table.get_item(Key={
            "primaryEmail": primaryEmail
        })['Item']['config']
        # for item in items:
        #     response.append({
        #         "name": item['name'],
        #         "email": item['email'],
        #         "period": item["period"],
        #         "filter": item["filters"]
        #     })
        for key, value in items.items():
            for i in range(len(value)):
                response.append({
                    "name": value[i]['name'],
                    "email" : value[i]['email'],
                    "filter" : value[i]['filters']
                })
        logger.info("Fetched Successfully")
        return response, 200
    except Exception as e:
        logger.error(str(traceback.format_exc()))
        return "Error Fetching", 500


def updateConfig(config, primaryEmail):
    tableName = 'gcp-configs'
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(tableName)
    try:
        
        logger.info('Fetching Table From DynamoDB')
        items = table.get_item(Key={
            "primaryEmail": primaryEmail
        })['Item']['config']
        period = config[0]['period']
        logger.info("Fetched Successfully")
        # for item in items[period]:
        #     logger.info("step 1")
        #     if config[0]['oldName'] == item['name']:
        #         logger.info("step 2")
        #         item['name'] = config[0]['name']
        #         item['email'] = config[0]['email']
        #         # item['period'] = config['period']
        #         item['filters'] = config[0]['filters']

        for key, value in items.items():
            logger.info("step 1")
            for i in range(len(value)):
                if config[0]['oldName'] == value[i]['name']:
                    logger.info("step 2")
                    value[i]['name'] = config[0]['name']
                    value[i]['email'] = config[0]['email']
                    value[i]['filters'] = config[0]['filters']

            logger.info("step 3")
        update_expressions = 'SET #config = :config'
        logger.info("step 4")
        expression_attribute_names = {
            '#config': 'config'
        }
        logger.info("step 5")
        expression_attribute_values = {
            ':config': items
        }
        logger.info("step 6")

        table.update_item(Key={
                'primaryEmail': primaryEmail
            },
            UpdateExpression=update_expressions,
            ExpressionAttributeNames=expression_attribute_names,
            ExpressionAttributeValues=expression_attribute_values
        )        

        logger.info("Updated Successfully")
        return "Successfully Updated", 200
    
    except Exception as e:
        logger.error(str(e))
        return "Error Updating", 500


def deleteConfig(name, primaryEmail):
    tableName = 'gcp-configs'
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(tableName)
    try:
        items = table.get_item(Key={
            "primaryEmail": primaryEmail
        })['Item']['config']

        # for i in range(len(items)):
        #     if items[i]['name'] == name:
        #         del items[i]
        #         break
        flag = False
        for key, value in items.items():
            for i in range(len(value)):
                if value[i]['name'] == name:
                    flag = True
                    del value[i]
                    break
        if flag ==  False:
            return "Not Found", 418           
        update_expressions = ['SET #config = :config']
        expression_attribute_names = {
            '#config': 'config'
        }
        expression_attribute_values = {
            ':config': items
        }

        table.update_item(Key={
                'primaryEmail': primaryEmail
            },
            UpdateExpression=', '.join(update_expressions),
            ExpressionAttributeNames=expression_attribute_names,
            ExpressionAttributeValues=expression_attribute_values,
        )        
        logger.info("Successfully deleted")
        return "Successfully Deleted", 200        

    except Exception as e:
        logger.error(str(e))
        return "Error Deleting", 500


def getGCPprojectId(emailId):

    dynamodb  = boto3.resource('dynamodb')
    table = dynamodb.Table(gcpDetailsTable)

    response = table.query(ProjectionExpression="billing_project_id",
            KeyConditionExpression=Key('gcp_primary_email').eq(emailId))

    billingProjectId=response['Items'][0]['billing_project_id']
    
    return str(billingProjectId)

def deleteGCPStoredReport(primaryEmail,data):

    
    try:
        s3=boto3.client('s3')
        database='reports'
        projectID=getGCPprojectId(primaryEmail)
        tableName=f"reports_{projectID.replace('-','_')}_billing"
        bucketName=f"opslyft-{projectID}-billing-reports"
        conn = psycopg2.connect(
                host=postgreCreds["host"],
                database=database,
                user=postgreCreds["user"],
                password=postgreCreds["password"])
        cur = conn.cursor()
        logger.info('made connection to reports db')
        for emailToDelete in data:
            url=emailToDelete['viewURL']
            key=url.split('/')[3]
        
            resp=s3.delete_object(Bucket=bucketName,Key=key)
            logger.info(f"Deleted {url} from s3")

            deleteTableQuery=f"delete from {tableName} where url='{url}'"
            cur.execute(deleteTableQuery)

        if resp:
            return True
        else:
            return False

    except:
        logger.error(traceback.format_exc())
    finally:
        conn.commit()
        cur.close()

def shareGCPStoredReport(primaryEmail,data,emails):

    
    try:
        s3=boto3.client('s3')
        projectID=getGCPprojectId(primaryEmail)
        tableName=f"reports_{projectID.replace('-','_')}_billing"
        bucketName=f"opslyft-{projectID}-billing-reports"
        for emailToShare in data:
            url=emailToShare['viewURL']
            reportName=emailToShare['reportName']
            key=url.split('/')[3]
            fileName=f'{key}'
            print(bucketName,key)
            s3.download_file(bucketName,key,f'mailServer/csvs/{fileName}')
            
            postData={
            "reportName":reportName,
            "csvName":fileName,
            "emails": emails
        }

            r=requests.post(url=mailUrl,json=postData)
            resp=r.json()['status']
        # print(r.text)
        if resp:
            return True
        else:
            return False

    except:
        logger.error(traceback.format_exc())
