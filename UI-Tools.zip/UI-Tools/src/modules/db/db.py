import boto3
from botocore.exceptions import ClientError

from config import logger

'''
This module provides the functionality for performing CRUD operations on a DynamoDB table(on AWS). It uses a 
"boto3" client for making the required API calls. 

Below are the syntax required by boto3 for making API calls.
'''

'''
Dynamodb required syntax:
'Attributes': {
    'string': {
        'S': 'string',
        'N': 'string',
        'B': b'bytes',
        'SS': [
            'string',
        ],
        'NS': [
            'string',
        ],
        'BS': [
            b'bytes',
        ],
        'M': {
            'string': {'... recursive ...'}
        },
        'L': [
            {'... recursive ...'},
        ],
        'NULL': True|False,
        'BOOL': True|False
    }
}

'S'=String
'N'=Number
'B'=Bytes



items structure:

item = {
    "primaryKey": "primaryKeyName",
    "attributes": {
        "Name": {
            "Value": "Value",
            "Type": "S|N|B|BS|NS etc."
        }
    }
}
'''


class DB:

    def __init__(self):
        self.client = boto3.client("dynamodb", region_name="us-east-1")

    def create_table(self, primary_key: str, primary_key_type: str, table_name: str) -> bool:
        """
        Creates a dynamodb table with the specified primary key and name

        :param primary_key: The primary_key of the table
        :param primary_key_type: The type of the primary key
        :param table_name: The name of the table to be created
        :return: bool
        """

        if primary_key_type not in ['S', 'N', 'B']:
            raise ValueError("Primary key must be one of 'S', 'N' and 'B'")

        try:
            logger.info("Creating table: ", table_name)
            self.client.create_table(
                AttributeDefinitions=[
                    {
                        'AttributeName': primary_key,
                        'AttributeType': primary_key_type
                    }
                ],
                TableName=table_name,
                KeySchema=[
                    {
                        'AttributeName': primary_key,
                        'KeyType': "HASH"
                    }
                ],
                BillingMode="PAY_PER_REQUEST"
            )

        except ClientError as e:
            logger.error(str(e))
            return False

        return True

    def put_item(self, item: dict, table_name: str) -> bool:
        """
        Inserts an item in the specified table. The item must have a primary key which must be unique. If the item is
        inserted successfully True is returned else False.

        :param item: The item to be inserted in the dynamodb table(Must follow a specific format as mentioned above)
        :param table_name: The name of the table in which the item has to be inserted
        :return: bool
        """

        primary_key = item["primaryKey"]
        Item = dict()

        for attribute in item["attributes"]:
            Item[attribute] = {
                item["attributes"][attribute]["Type"]: item["attributes"][attribute]["Value"]
            }

        try:
            logger.info("Inserting item in database")
            self.client.put_item(
                TableName=table_name,
                Item=Item,
                ConditionExpression=f"attribute_not_exists({primary_key})"
            )
        except ClientError as e:
            logger.error(str(e))
            return False

        return True

    def update_item(self, item: dict, table_name: str) -> bool:
        """
        Updates an existing item in the specified table. If the item is not presented, it is inserted in the table. On
        successful update/insert True is returned else False.

        :param item: The item to be updated(Must contain the primary key of the item to be updated)
        :param table_name: The name of the table in which the item has to be
        :return: bool
        """

        primary_key = item["primaryKey"]
        primary_key_value = None
        primary_key_type = None
        Item = dict()

        for attribute in item["attributes"]:
            if attribute == primary_key:
                primary_key_value = item["attributes"][attribute]["Value"]
                primary_key_type = item["attributes"][attribute]["Type"]
                continue

            Item[attribute] = {
                "Value": {
                    item["attributes"][attribute]["Type"]: item["attributes"][attribute]["Value"]
                },
            }

        try:
            logger.info("Updating item in database")
            self.client.update_item(
                TableName=table_name,
                Key={
                    primary_key: {
                        primary_key_type: primary_key_value
                    }
                },
                AttributeUpdates=Item
            )
        except Exception as e:
            logger.error(str(e))
            return False

        return True

    def get_item(self, item: dict, table_name: str) -> bool or dict:
        """
        Get an item already present in the specified table. The item is identified by the primary key. If the
        item(primary key) is present in the table, then the entire content is returned else False.

        :param item: The item to be read(Must contain the primary key of the item to be read)
        :param table_name: The name of the table in which the item has to be
        :return: bool or dict
        """

        primary_key = item["Key"]
        primary_key_value = item["Value"]
        primary_key_type = item["Type"]

        logger.info("Getting item from database")
        response = self.client.get_item(
            TableName=table_name,
            Key={
                primary_key: {
                    primary_key_type: primary_key_value
                }
            }
        )

        if response.get("Item") is None:
            logger.error("Item not found")
            return False

        return response["Item"]
