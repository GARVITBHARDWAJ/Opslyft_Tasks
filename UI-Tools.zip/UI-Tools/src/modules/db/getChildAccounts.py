import boto3
from config import logger
from boto3.dynamodb.conditions import Key, Attr


# Get the service resource.
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('user-info')

def getCompany(accountId:str):
    response = table.get_item(
        Key={
            'accountId': accountId,
            },
        ProjectionExpression = "companyName"
    )
    if response.get("Item") is None:
        logger.error("Item not found")
        return None
    return (response["Item"])


def getChildAccounts(accountId:str):
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    logger.info('connected to database using boto3')
    table = dynamodb.Table('user-info')
    data = table.scan()
            #data = res.get('Items')

    logger.info('scan complete')
    linked_acc = list()
    for i in data['Items']:
        if i['destBucket']==f"{accountId}-cur-bucket":
            linked_acc.append(i['accountId'])
    return linked_acc

    

