from flask import Flask,request,Response
from config import logger, tables, user
import traceback
import json
import pymysql
from datetime import datetime, date, timedelta
import time
from .statements import createStatement
from credentials import db_credentials
from src.modules.db import getChildAccounts

user=db_credentials['username']
dbpassword=db_credentials['password']
host=db_credentials['host']
    
def getPrevLastMonth():
    first = date.today().replace(day=1)
    monthEnd = first - timedelta(days=1)
    monthStart = monthEnd.replace(day=1)
    prevMonthEnd = monthStart - timedelta(days=1)
    prevMonthStart = prevMonthEnd.replace(day=1)
    return [prevMonthStart, prevMonthEnd]

def getLastMonth():
    first = date.today().replace(day=1)
    monthEnd = first - timedelta(days=1)
    monthStart = monthEnd.replace(day=1)
    return [ monthStart,monthEnd ]

def getMonthToNow():
    start = date.today().replace(day=1)
    end = date.today()
    return [start,end]

def remainingDays(): 
    nextMonth = date.today().replace(day=28) + timedelta(days=4)
    lastday = nextMonth - timedelta(days=nextMonth.day)
    return lastday.day - date.today().day

def calForcast(prev30:float, mnth2date:float):
    if prev30:
        float(prev30)
    else:
        prev30 = 0
    if mnth2date:
        float(mnth2date)
    else:
        mnth2date = 0
    return (prev30/30)*remainingDays()+mnth2date if (prev30/30)*remainingDays()+mnth2date else None

#----------------------Generate response for IRM function ----------------
def responseGenerator(accountId:str,result:tuple):
    reports = []
    try:
        if result:
            temp = {"count":0,"servicesName":"","price":0,"statement":"","resources":[]}
            prev = None
            flag = 0
            resourceList = []
            for i in result:
                if i[0] != prev:
                    if flag == 1:
                        temp['price'] = round(temp['price']*remainingDays(),2)
                        temp['resources'] = resourceList
                        temp['statement'] = createStatement(serviceName=temp["servicesName"],count=temp["count"])
                        reports.append(temp)
                    temp = {"count":0,"servicesName":"","price":0,"statement":"","resources":[]}
                    resourceList = []
                temp["count"] +=1
                temp["servicesName"] = i[0]
                temp["price"] += i[1]
                resourceList.append({"resourceId":i[2].strip('\"'),"cost":i[1]})
                flag = 1
                prev = i[0]
            temp['price'] = round(temp['price']*remainingDays(),2)
            temp['resources'] = resourceList
            temp['statement'] = createStatement(serviceName=temp["servicesName"],count=temp["count"])
            reports.append(temp)
    except Exception as e:
        logger.error(traceback.format_exc(e))
    
    return reports


#--------------------- Functions for query execution: takes sql string and Connection() object ---------------------------
def executeQuery(sql:str,con):
    result = None
    try:
        with con.cursor() as cur:
            logger.info(f"Executing Sql query ")
            cur.execute(sql)
            result = cur.fetchall()
    except:
        logger.error(traceback.format_exc())
    finally:
        logger.info(f"Database closed successfully ")
        
    return result


# -------------------------------for reports section -----------------------------
def dailyCost(accountId:str):
    database='reports'
    try:
        con = pymysql.connect(database=database, user=user, password=dbpassword, host=host)
        logger.info(f"Database {database} opened successfully ")
        tableName=f"reports{accountId}"
        sql=f"select url, round(totalCost,2) from {tableName} where accountId='{accountId}' and reportType='Daily' order by date desc limit 1"
        result = executeQuery(sql=sql,con=con)
        if len(result):
            for i in result:
                result={'url':i[0],'price':i[1]}
        else:
            result={'url':None,'price':None}
    except:
        logger.error(traceback.format_exc())
    logger.info("/home/Report-daily cost done!")
    return result


def weeklyCost(accountId:str):
    database='reports'
    try:
        con = pymysql.connect(database=database, user=user, password=dbpassword, host=host)
        logger.info(f"Database {database} opened successfully ")
        tableName=f"reports{accountId}"
        sql=f"select url, round(totalCost,2) from {tableName} where accountId='{accountId}' and reportType='Weekly' order by date desc limit 1"
        result = executeQuery(sql=sql,con=con)
        if result:
            for i in result:
                result={'url':i[0],'price':i[1]}
        else:
            result={'url':None,'price':None}
    except:
        logger.error(traceback.format_exc())
    logger.info("/home/Report-weekly cost done!") 
    return result

# -----------------------------for trends section------------------------
def lastMonthCost(accountId:str):
    database=f'master_{accountId}'
    try:
        con = pymysql.connect(database=database, user=user, password=dbpassword, host=host)
        logger.info(f"Database {database} opened successfully ")
        begin, end = getLastMonth()
        tableName=f"MasterCur{accountId}"
        sql=f'select round(sum(lineitemunblendedcost),2) from {tableName} where DATE(lineitemusagestartdate) BETWEEN "{begin}" AND "{end}" and lineitemlineitemtype="Usage"'
        result= executeQuery(sql=sql,con=con)
        return result[0][0] if result[0][0] else 0
    except:
        logger.error(traceback.format_exc())
        return 0
    logger.info("/home/trends-LastMonthCost cost done!")
    #return result[0][0] if result[0][0] else 0


def monthToDateCost(accountId:str):
    database=f'master_{accountId}'
    try:
        con = pymysql.connect(database=database, user=user, password=dbpassword, host=host)
        logger.info(f"Database {database} opened successfully ")
        begin, end = getMonthToNow()
        tableName=f"MasterCur{accountId}"
        sql=f'select round(sum(lineitemunblendedcost),2) from {tableName} where (DATE(lineitemusagestartdate) BETWEEN "{begin}" AND "{end}") and lineitemlineitemtype="Usage"'
        result = executeQuery(sql=sql,con=con)
        return result[0][0] if result[0][0] else 0
    except:
        logger.error(traceback.format_exc())
        return 0
    logger.info("/home/trends-MonthToDate cost done!")
    #return result[0][0] if result[0][0] else 0


def forcastedCost(accountId:str,cost:float):
    database=f'master_{accountId}'
    response = None
    try:
        con = pymysql.connect(database=database, user=user, password=dbpassword, host=host)
        logger.info(f"Database {database} opened successfully ")
        end = date.today() - timedelta(days=1)
        begin = end - timedelta(days=30)
        tableName=f"MasterCur{accountId}"
        sql=f'select round(sum(lineitemunblendedcost),2) from {tableName} where (DATE(lineitemusagestartdate) BETWEEN "{begin}" AND "{end}") and lineitemlineitemtype="Usage"'
        result= executeQuery(sql=sql,con=con)
        response = round(calForcast(prev30 = result[0][0],mnth2date = cost),2)
        return response if response else 0
    except:
        logger.error(traceback.format_exc())
        return 0
    logger.info("/home/trends-forcasted cost done!")
    #return response if response else 0

# ---------------------------for cost savings --------------------------
def homeIrm(accountId:str):
    database = f'master_{accountId}'
    finalResponse = dict()
    accountList = getChildAccounts(accountId=accountId)
    try:
        con = pymysql.connect(database = database,user=user, password=dbpassword, host=host)
        logger.info(f"Database {database} opened successfully ")
        for id in accountList:
            tableName=f'{id}_irm'
            sql = f'select service, round(price,2), json_extract(resource, "$.identifier") as instanceId from {tableName} order by 1'
            result = executeQuery(sql=sql,con=con)
            reports = responseGenerator(accountId=id,result=result)
            finalResponse[f"{id}"] = reports
        con.close()    
    except:
        logger.error(traceback.format_exc())
    finally:
        logger.info("/home/irm-IRM section done!")
    return finalResponse
        #conn.close()
    
    logger.info("/home/irm-IRM section done!")
    return reports
#-----------------------First time Landing Page---------------------------

def get_month_forecast_bill(client):
    first = date.today()
    nextMonth = date.today().replace(day=28) + timedelta(days=4)
    lastday = nextMonth - timedelta(days=nextMonth.day)
    result = {"monthForecast": dict()}
    response = client.get_cost_forecast(TimePeriod={'Start': f'{first}','End': f'{lastday}'},Metric='UNBLENDED_COST', Granularity='MONTHLY')
    result["monthForecast"]['totalAmount'] = float(response['Total']['Amount'])
    return result

def get_month_to_date_bill(client):
    begin, end = getMonthToNow()
    month_start, month_end = getLastMonth()
    result = {"monthToDate": dict()}
    past_result = {"monthToDate": dict()}
    res = get_bill(client=client, begin=begin, end=end, month_start=month_start, month_end=month_end,past_result=past_result, result=result,  datatype="monthToDate")
    return res

def get_prev_month_bill(client):
    begin, end = getLastMonth()
    month_start, month_end = getPrevLastMonth()
    result = {"prevMonth": dict()}
    past_result = {"prevMonth": dict()}
    res = get_bill(client=client, begin=begin, end=end, month_start=month_start, month_end=month_end,past_result=past_result, result=result,  datatype="prevMonth")
    return res

def get_bill(client,begin, end, month_start, month_end, past_result, result, datatype):
    total = 0
    result = result
    past_result = past_result
    
    response = client.get_cost_and_usage(TimePeriod={'Start': f"{begin}", 'End':  f"{end}"}, Granularity='MONTHLY', Metrics=['UnblendedCost'], GroupBy=[{'Type': 'DIMENSION', 'Key': 'SERVICE'}])
    response_for_prev_month = client.get_cost_and_usage(TimePeriod={'Start': f"{month_start}", 'End':  f"{month_end}"}, Granularity='MONTHLY', Metrics=['UnblendedCost'], GroupBy=[{'Type': 'DIMENSION', 'Key': 'SERVICE'}])
    
    services = response["ResultsByTime"][0]["Groups"]
    past_services = response_for_prev_month["ResultsByTime"][0]["Groups"]
    past_result[datatype]["services"] = {}
    
    for past_service in past_services:
        past_result[datatype]["services"][past_service["Keys"][0]] = {}
        past_result[datatype]["services"][past_service["Keys"][0]]["Amount"]=past_service["Metrics"]["UnblendedCost"]["Amount"]
    
    result[datatype]["services"]={}
    
    for service in services:
        try:
            
            service_name = service["Keys"][0]
            result[datatype]["services"][service_name]={}
            single_service = result[datatype]["services"][service_name]
            past_services_list = past_result[datatype]["services"]
            
            single_service["Amount"]=service["Metrics"]["UnblendedCost"]["Amount"]
           
            service_amount = single_service["Amount"]
            
            total+=abs(float(service["Metrics"]["UnblendedCost"]["Amount"]))
        
            if (past_services_list.get(service_name)!=None) and abs(float(past_services_list[service_name]["Amount"])) >= abs(float(service_amount)):
                single_service["change"]="Decrease"
            elif past_services_list.get(service_name)!=None and abs(float(past_services_list[service_name]["Amount"])) < abs(float(service_amount)):
                single_service["change"]="Increase"
            elif past_services_list.get(service_name)==None:
            
                single_service["change"]="New"
        
        except Exception as e:
            logger.error(str(e))
    
    result[datatype]["totalAmount"]=total
    return result
