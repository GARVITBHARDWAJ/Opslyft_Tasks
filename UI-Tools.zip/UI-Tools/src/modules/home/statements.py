
def createStatement(serviceName:str,count:float):
    statement = {
        "AmazonRDS": f"{count} rds db instances found having zero connection count for last 7 days.",
        "ELB": f"{count} elb found having zero request/healthy host count for last 7 days.",
        "ELBV2": f"{count} elbv2 found having zero request/healthy host count for last 7 days.",
        "AmazonEC2": f"{count} ec2 instances found that are below 10% CPU Utilization for last 7 days.",
        "AmazonDynamoDB": f"{count} dynamodb tables found that have zero consumed read/write capacity units for last 7 days.",
        "AWSLambda": f"{count} lambda functions found having zero invocations for last 7 days.",
        "AmazonRedshift": f"{count} redshift clusters found having zero connections for last 7 days.",
        'EIP': f"{count} unassociated elastic IPs found.",
        "EBS": f"{count} unattached ebs volumes found.",
        "AmazonApiGateway": f"{count} api gateway APIs found having zero api calls for last 7 days.",
        "NAT": f"{count} nat gateway found having zero active connections for last 7 days.",

    }
    if serviceName in statement:
        return statement[serviceName]
    else:
        return None