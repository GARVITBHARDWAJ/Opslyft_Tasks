from src.modules.s3_bucket.bucket import Bucket
