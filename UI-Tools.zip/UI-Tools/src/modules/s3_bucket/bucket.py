import json
import boto3

from config import logger


class Bucket:
    def __init__(self, role_arn: str):
        self.role_arn = role_arn
        self.account_id = role_arn.split(":")[4]
        self.bucket_name = f"{self.account_id}-cur-bucket"

    def get_bucket_policy(self, bucket_name: str) -> dict:
        """
        Returns the bucket policy.

        :param bucket_name: The name of the S3 bucket for which the policy is being created
        :return: the polocy of the bucket
        """

        bucket_policy = {
            "Version": "2008-10-17",
            "Id": "Customer-Bucket-Objects-Replication",
            "Statement": [
                {
                    "Sid": "Stmt1335892150622",
                    "Effect": "Allow",
                    "Principal": {
                        "Service": "billingreports.amazonaws.com"
                    },
                    "Action": [
                        "s3:GetBucketAcl",
                        "s3:GetBucketPolicy"
                    ],
                    "Resource": f"arn:aws:s3:::{bucket_name}"
                },
                {
                    "Sid": "Stmt1335892526596",
                    "Effect": "Allow",
                    "Principal": {
                        "Service": "billingreports.amazonaws.com"
                    },
                    "Action": "s3:PutObject",
                    "Resource": f"arn:aws:s3:::{bucket_name}/*"
                },
                {
                    "Sid": "S3ReplicationPolicy",
                    "Effect": "Allow",
                    "Principal": {
                        "AWS": self.role_arn
                    },
                    "Action": [
                        "s3:*"
                    ],
                    "Resource": [
                        f"arn:aws:s3:::{bucket_name}",
                        f"arn:aws:s3:::{bucket_name}/*"
                    ]
                }
            ]
        }

        return bucket_policy

    def create_bucket_opslyft_acc(self) -> bool:
        """
        Creates an s3 bucket for the user in OpsLyft account for storing the CUR report.

        :return: True/False for success/failure
        """

        s3_client = boto3.client("s3")

        try:
            logger.info(f"Creating bucket in OpsLyft Account: {self.bucket_name}")
            s3_client.create_bucket(Bucket=self.bucket_name)
            logger.info(f"Attaching policy to {self.bucket_name}")
            s3_client.put_bucket_policy(
                Bucket=self.bucket_name,
                Policy=json.dumps(self.get_bucket_policy(bucket_name=self.bucket_name))
            )

        except s3_client.exceptions.BucketAlreadyExists:
            logger.warning("Bucket already exists")
            return True

        except Exception as e:
            logger.error(str(e))
            return False

        return True

    def attach_bucket_policy_user_acc(self, session: boto3.session.Session, bucket_name: str) -> bool:
        """
        Alters bucket policy of user account 
        """
        s3_client = session.client('s3')

        try:
            logger.info("Fetching user bucket policy")
            policy = json.loads(s3_client.get_bucket_policy(Bucket=bucket_name)['Policy'])
            
            statement = {
                "Sid": "S3ReplicationPolicy",
                "Effect": "Allow",
                "Principal": {
                    "AWS": self.role_arn
                },
                "Action": [
                    "s3:*"
                ],
                "Resource": [
                    f"arn:aws:s3:::{bucket_name}",
                    f"arn:aws:s3:::{bucket_name}/*"
                ]
            }

            policy['Statement'].append(statement)
            s3_client.put_bucket_policy(
                Bucket=bucket_name,
                Policy=json.dumps(policy)
            )
        
        except s3_client.exceptions.NoSuchBucketPolicy:
            s3_client.put_bucket_policy(
                Bucket=bucket_name,
                Policy=json.dumps(self.get_bucket_policy(bucket_name=bucket_name))
            )
            return True
        
        except Exception as e:
            logger.error(str(e))
            return False
        
        return True

    def create_bucket_user_acc(self, session: boto3.session.Session, bucket_name: str) -> bool:
        """
        Creates an S3 bucket in User's AWS account for storing the generated CUR.

        :param session: Boto3 session object
        :param bucket_name: The name of the CUR bucket to be created in user account
        :return: True/False for success/failure
        """

        s3_client = session.client("s3")

        try:
            logger.info("Creating bucket in user account")
            s3_client.create_bucket(Bucket=bucket_name)
            logger.info("Attaching policy")
            s3_client.put_bucket_policy(
                Bucket=bucket_name,
                Policy=json.dumps(self.get_bucket_policy(bucket_name=bucket_name))
            )

        except s3_client.exceptions.BucketAlreadyExists:
            logger.warning("Bucket already exists")
            return True

        except Exception as e:
            logger.error(str(e))
            return False

        return True

    def create_buckets(self, session: boto3.session.Session, bucket_name: str, company_name: str) -> bool:
        """
        Calls the create_bucket_my_acc and create_bucket_user_acc.

        :return: True/False for success/failure
        """
        if company_name.lower() == "niki":
            return self.create_bucket_opslyft_acc() and self.attach_bucket_policy_user_acc(session=session, bucket_name=bucket_name)
        else:
            return self.create_bucket_opslyft_acc() and self.create_bucket_user_acc(session=session, bucket_name=bucket_name)