from src.modules.cur.cur import enable_cur
