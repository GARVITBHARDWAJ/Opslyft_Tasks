import boto3

from config import logger


def enable_cur(session: boto3.session.Session, report_name: str, bucket_name: str) -> bool:
    """
    Enables CUR report in user's AWS account with the following configuration.

    :param session: Boto3 session object
    :param report_name: The name of the cur report to be created
    :param bucket_name: The name of the bucket in which the report should be dumped
    :return: True/False for success/failure
    """

    cur_client = session.client("cur")

    try:
        logger.info("Enabling cur report in user account")
        cur_client.put_report_definition(
            ReportDefinition={
                "ReportName": report_name,
                "TimeUnit": "HOURLY",
                "Format": "textORcsv",
                "Compression": "GZIP",
                "AdditionalSchemaElements": [
                    "RESOURCES"
                ],
                "S3Bucket": bucket_name,
                "S3Prefix": "main",
                "S3Region": "us-east-1",
                "RefreshClosedReports": True,
                "ReportVersioning": "CREATE_NEW_REPORT"
            }
        )

    except cur_client.exceptions.DuplicateReportNameException:
        logger.warning("Report already exists")
        return True

    except Exception as e:
        logger.error(str(e))
        return False

    return True
