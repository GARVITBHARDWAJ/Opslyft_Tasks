from flask import Flask,request,Response
import json
import logging
import boto3
from config import logger
from botocore.exceptions import ClientError
from src.modules.alerts.getRules import generate_response
import traceback
import requests

logging.basicConfig(
    format='%(asctime)s %(levelname)-8s %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def find_all_ids(accountId):
    try:
        dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
        logger.info('connected to database using boto3')
        table = dynamodb.Table('user-info')
        data = table.scan()
        #data = res.get('Items')
        logger.info('scan complete')
        linked_acc = list()
        for i in data['Items']:
            if i['destBucket']==f"{accountId}-cur-bucket":
                linked_acc.append(i['accountId'])
        return linked_acc
        logger.info('data returned in form of list')
    except Exception as e:
        print(str(traceback.format_exc()))
        return generate_response(400, {'messge': str(e)})

