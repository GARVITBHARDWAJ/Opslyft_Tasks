from flask import Flask,request,Response
from config import logger, tables, user
import traceback
import json
import pymysql
from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta
import time, calendar
from credentials import db_credentials

user=db_credentials['username']
dbpassword=db_credentials['password']
host=db_credentials['host']



def mapFilters(filter:dict):
    """
	This function replace the name of filters with that of in database tables
    
	:filter: A dictionary that contails all the parameter of filteration
	:return: A dictionary with new key names
	"""
    names = {
        "services":"lineitemproductcode",
        "linkedAccounts":"lineItemUsageAccountId",
        "productregions":"productregion",
        "instancetypes":"productinstanceType",
        "resourceIds":"lineItemResourceId",
    }
    newFilter = dict()
    for key in filter:
        if key in names:
            newFilter[names[key]] = filter[key]
        else:
            newFilter[key] = filter[key]
    return newFilter

# ----------------------- It returns the starting and end date for a given period-----------------
def getTimeRange(period:str):
    if period == "month":
        begin = date.today().replace(day=1) - relativedelta(months=5)
        end = date.today()
    elif period == "week":
        begin = date.today() - relativedelta(weeks=6)
        end = date.today()
    else:
        begin = date.today() - relativedelta(days=30)    
        end = date.today()
    return [ begin,end ]

# -------------------------It returns first and last date of a week from week no.---------------
def getDateRangeFromWeek(p_year,p_week):
    firstdayofweek = datetime.strptime(f'{p_year}-W{int(p_week )- 1}-1', "%Y-W%W-%w").date()
    lastdayofweek = firstdayofweek + timedelta(days=6.9)
    return firstdayofweek, lastdayofweek

#------------------------- It takes multiple sql query strings and execute them all ------------- 
def executeQuery(sql:dict,con):
    returnValue = {}
    try:
        with con.cursor() as cur:
            for i in sql:
                logger.info(f"Executing query for {sql[i]} wise trend")
                cur.execute("%s%s%s"%(sql[i]['mainSql'],sql[i]['conditionSql'],sql[i]['endSql']))
                result = cur.fetchall()
                if len(result):
                    returnValue[f"{i}"] = result
                else:
                    returnValue[f"{i}"] = None
    except Exception as e:
        logger.error(traceback.format_exc(e))
    
    finally:
        con.close()
        
    return returnValue


def queryGenerater(tableName:str,filter:dict,period:str):
    """
	Creates a dynamic sql query on the basis of the parameters given

	:tableName: Name of the table 
	:filter: A dictionary that contails all the parameter of filteration

	:return: A single string of sql query
	"""
    logger.info(f"Generating Sql query string for the table {tableName}")

    mainSql = "select round(sum(lineitemunblendedcost),2) , %s(lineitemusagestartdate) from %s where "%(period,tableName)
    conditionSql =""

    for key in filter:
        if len(filter[key]) and (key !="tags"):
            values = "\",\"" .join(map(str,filter[key]))
            conditionSql+= "%s in (\""%(key,)+"%s"%(values,)+"\") and "
        if key == "tags" and len(filter["tags"]):
            for tag in filter[key]:
                if len(filter[key][tag]):
                    values = "\",\"" .join(map(str,filter[key][tag]))
                    conditionSql+= "%s in (\""%(tag,)+"%s"%(values,)+"\") and "

    begin, end = getTimeRange(period=period)
    endSql = 'date(lineItemUsageStartDate) between "%s" and "%s" and '%(begin,end)
    endSql +=f'lineItemLineItemType = "Usage" group by 2'       

    return [mainSql,conditionSql,endSql]

def responseGenerator(result:tuple,period:str):
    """
	Creates and set a json like response according to day/week/month 

	:result: A tuple of the raw response from fetching DB 
	:period: A string which defines a period (eg. day/week/month)

	:return: A single dictionary with proccessed response
	"""
    logger.info(f"Generating response for the fetched result")

    results = {}
    currentYearMonths = {}
    previousYearMonths = {}
    if result:
        for timeNcost in result:
            if period == "month":
                if date.today().month < timeNcost[1]:
                    monthAbrevation = calendar.month_abbr[timeNcost[1]]
                    previousYearMonths[f"{monthAbrevation}"] = timeNcost[0]
                else:
                    monthAbrevation = calendar.month_abbr[timeNcost[1]]
                    currentYearMonths[f"{monthAbrevation}"] = timeNcost[0]
            if period == "week":
                if timeNcost[1]+1 > date.today().isocalendar()[1]:
                    year = date.today().year -1
                else:
                    year = date.today().year
                firstdate, lastdate =  getDateRangeFromWeek(year,timeNcost[1]+1)
                # generating key with date and month abbrevation (beg and end of week)
                periodAbbr = f"{firstdate.day} {calendar.month_abbr[firstdate.month]} - {lastdate.day} {calendar.month_abbr[lastdate.month]}"
                results[f"{periodAbbr}"] = timeNcost[0]
            if period == "date":
                getDate = datetime.strptime(str(timeNcost[1]),"%Y-%m-%d")
                # generating key with date and month 
                results[f"{getDate.day} {calendar.month_abbr[getDate.month]}"] = timeNcost[0]
        # arranging months in a proper oder
        if period == "month":
            if previousYearMonths:
                results.update(previousYearMonths)
            if currentYearMonths:
                results.update(currentYearMonths)
    else:
        results = 0

            
    return results



# ----------------------main function which is calling above functions-------------------
def filteredCost(accountId:str,filter:dict):
    database=f'master_{accountId}'
    try:
        con = pymysql.connect(database=database, user=user, password=dbpassword, host=host)
        logger.info(f"Database: {database} opened successfully")

        filter = mapFilters(filter=filter)

        sqlList = {"month":{},"date":{},"week":{}}

        tableName=f"MasterCur{accountId}"
        sqlList['month']['mainSql'],sqlList['month']['conditionSql'],sqlList['month']['endSql'] = queryGenerater(tableName=tableName,filter=filter,period="month")
        sqlList['date']['mainSql'],sqlList['date']['conditionSql'],sqlList['date']['endSql'] = queryGenerater(tableName=tableName,filter=filter,period="date")
        sqlList['week']['mainSql'],sqlList['week']['conditionSql'],sqlList['week']['endSql'] = queryGenerater(tableName=tableName,filter=filter,period="week")
        result = executeQuery(sql=sqlList,con=con)

        if result:
            result['month'] = responseGenerator(result=result['month'],period='month')
            result['date'] = responseGenerator(result=result['date'],period="date")
            result['week'] = responseGenerator(result=result['week'],period="week")
        else:
            result = None

    except Exception as e:
        logger.error(traceback.format_exc(e))
    finally:
        logger.info("/alert/filterCostTrends  done!")

    return result
