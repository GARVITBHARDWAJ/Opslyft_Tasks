import json
import logging

import boto3
from botocore.exceptions import ClientError
# from botocore.vendored import requests
# from srauthentication import validate_login
from src.modules.alerts.authentication import validate_login
import requests
import traceback

logging.basicConfig(
    format='%(asctime)s %(levelname)-8s %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def generate_response(status_code, body):
    response = {
        'statusCode': status_code,
        'body': json.dumps(body)
    }
    logger.info("Generating response")
    return response

def is_user_authenticated(access_token):
    resp = validate_login(access_token)

    if resp['status_code'] == 200:
        account_id = resp['body']['account_id']
        logger.info(account_id)
        return True, account_id
    else:
        logger.info('account id not found')
        return False, None

def delete(account_id,body):

    logger.info('Verifying access token')

    config = body
    alertName=config['alert_name']
    table_name = 'configs'
    logger.info('Connecting to DynamoDB')
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(table_name)
    try:
        logger.info('Getting Item from dynamodb')
        data = table.get_item(Key={'accountId': account_id})
        logger.info('Retrieved Item successfully')
        data=data['Item']
        try:
            for rules in data['accountsConfig']:
                if rules['Name'] == alertName:
                    logger.info('Alert Exists')
                    a=data['accountsConfig'].index(rules)
                    update_expressions = f"REMOVE accountsConfig[{a}]"
                    table.update_item(
                        Key={'accountId': account_id},
                        UpdateExpression=update_expressions
                    )

                    return generate_response(200,{'message':f'Alert {alertName} Deleted'})
        except Exception as e:
            print(str(e))
            logger.warning( f'Alert {alertName} does not exist')
            return generate_response(200, {'message': f'Alert {alertName} does not exist'})

    except Exception as e:
            print(str(traceback.format_exc()))
            return generate_response(400, {'message': str(e)})