import json
import logging
from flask import Response
import boto3
from botocore.exceptions import ClientError
# from botocore.vendored import requests
from src.modules.alerts.authentication import validate_login
import requests
import traceback

logging.basicConfig(
    format='%(asctime)s %(levelname)-8s %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def generate_response(status_code, body):
    response = {
        'statusCode': status_code,
        'body': json.dumps(body)
    }
    logger.info("Generating response")
    return response

def capitalize_keys(globals):
    result = dict()
    for key, value in globals.items():
        upper_key = key[0].upper()+key[1:]
        result[upper_key] = value
    return result

def lowercase_object_keys(obj):
    return dict((k.lower(), v) for k, v in obj.items())

def is_user_authenticated(access_token):
    resp = validate_login(access_token)

    if resp['status_code'] == 200:
        account_id = resp['body']['account_id']
        logger.info(account_id)
        return True, account_id
    else:
        logger.info('account id not found')
        return False, None

def get_rules(accountId):
    logger.info('Verifying access token')
    logger.info('event')

    #is_authenticated, account_id = is_user_authenticated(access_token)
    # is_authenticated = True
    #config = body
    # Id = config['account_id']
    # account_id = Id
    table_name = 'configs'
    logger.info('Connecting to DynamoDB')
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(table_name)

    try:
        logger.info('Getting Item from dynamodb')
        data = table.get_item(
            Key={
                'accountId': accountId,
            }
        )
        logger.info('Retrieved Item successfully')

        item = data['Item']
        globals = dict()
        for key, value in item.items():
            globals.update({key:value})

        globals.pop('accountsConfig')
        globals.pop('accountId')

        Globals = capitalize_keys(globals)

        alert_config = {
            'Accounts' : [],
            'Globals': Globals
        }
        for account in item["accountsConfig"]:
            if str(account['Id']) == str(accountId):
                alert_config['Accounts'].append(account)
        return  alert_config

    except Exception as e:
            logger.warn("Account ID not found")
            return Response(json.dumps({"response":"Data not found"}),status=204,mimetype='application/json')
