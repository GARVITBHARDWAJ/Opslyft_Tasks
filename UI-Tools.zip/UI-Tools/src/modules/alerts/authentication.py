import json
import logging
import boto3

logging.basicConfig(
    format='%(asctime)s %(levelname)-8s %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

clientId = '106p8cf38rigggfapojr5rnv4k'


# def login(event, context):
#     logger.info("Extracting email and password")

#     data = json.loads(event['body'])
#     email = data['email']
#     password = data['password']

#     client = boto3.client('cognito-idp')

#     try:
#         logger.info("Authenticating with Cognito")
#         resp = client.initiate_auth(
#             AuthFlow='USER_PASSWORD_AUTH',
#             AuthParameters={
#                 'USERNAME': email,
#                 'PASSWORD': password
#             },
#             ClientId=clientId,
#         )

#         resp = resp['AuthenticationResult']
#         status_code = 200
#         body = {
#             "accessToken": resp['AccessToken'],
#             "idToken": resp['IdToken']
#         }

#     except client.exceptions.NotAuthorizedException:
#         logger.info("NotAuthorizedException occured")
#         status_code = 401
#         body = {
#             "error": "User not authorized",
#         }

#     except client.exceptions.UserNotConfirmedException:
#         logger.info("UserNotConfirmedException occured")
#         status_code = 401
#         body = {
#             "error": "User email not confirmed",
#         }

#     except Exception:
#         logger.info("Miscellaneous Exception occured")
#         status_code = 400
#         body = {
#             "error": "Something went wrong",
#         }

#     response = {
#         "statusCode": status_code,
#         "body": json.dumps(body)
#     }

#     return response


def lowercase_object_keys(obj):
    return dict((k.lower(), v) for k, v in obj.items())


def validate_login(access_token):
    client = boto3.client('cognito-idp')

    try:
        resp = client.get_user(
            AccessToken=access_token
        )

        attributes = resp['UserAttributes']
        account_id = ""

        for attr in attributes:
            if attr['Name'] == 'custom:roleARN':
                account_id = attr['Value'].split(':')[4]
                break
            if attr['Name'] == 'custom:gcpAccountId':
                account_id = attr['Value']
                break
        status_code = 200
        body = {
            "account_id": account_id,
        }

    except Exception as e:
        status_code = 401
        body = {
            "error": str(e),
        }
    
    response = {
        "status_code": status_code,
        "body": body
    }
    return response
