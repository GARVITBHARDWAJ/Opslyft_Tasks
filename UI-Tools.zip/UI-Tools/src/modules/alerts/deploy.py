import json
import logging

import boto3
from botocore.exceptions import ClientError
# from botocore.vendored import requests
import requests
import traceback

logging.basicConfig(
    format='%(asctime)s %(levelname)-8s %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def generate_response(status_code, body):
    response = {
        'statusCode': status_code,
        'body': json.dumps(body)
    }
    logger.info("Generating response")
    return response

def lowercase_object_keys(obj):
    return dict((k.lower(), v) for k, v in obj.items())

def lowercase_first_letter(word):
    return word[0].lower() + word[1:]

def deploy(account_id,body):
    logger.info('Verifying access token')
    logger.info('event')
    alert_config = body
    accountsConfig = alert_config['Accounts'][0]['Rules']

    table_name = 'configs'
    logger.info('Connecting to DynamoDB')
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(table_name)

    try:

        update_expressions = ['SET #accountsConfig = :accountsConfig']

        expression_attribute_names = {
            '#accountsConfig': 'accountsConfig'
        }

        expression_attribute_values = {
            ':accountsConfig': accountsConfig
        }

        for key, value in alert_config['Globals'].items():
            key = lowercase_first_letter(key)
            update_expressions.append(f'#{key} = :{key}')
            expression_attribute_names[f'#{key}'] = key
            expression_attribute_values[f':{key}'] = value

        logger.info('Updating Item in DynamoDB')
        table.update_item(
            Key={
                'accountId': account_id,
            },
            UpdateExpression=', '.join(update_expressions),
            ExpressionAttributeNames=expression_attribute_names,
            ExpressionAttributeValues=expression_attribute_values,
        )
        logger.info('Updated Item successfully')

        return generate_response(200, {'message': 'Alert Configuration Successfully Deployed'})

    except ClientError as e:
        logger.info('Item does not exists')

        item = {
            'accountId': account_id,
            'accountsConfig': accountsConfig,
        }

        for key, value in alert_config['Globals'].items():
            item[lowercase_first_letter(key)] = value

        alert_config['accountId'] = account_id

        logger.info('Creating new item')
        table.put_item(
            Item=item
        )
        logger.info('Created Item successfully')

        return generate_response(200, {'message': 'success'})

    except Exception as e:
        return generate_response(400, {'message': str(e)})