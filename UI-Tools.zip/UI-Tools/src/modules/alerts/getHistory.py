import re
from flask import request,Request, Response
import json
import pymysql
from credentials import db_credentials
import logging
import traceback
from config import logger

logging.basicConfig(
    format='%(asctime)s %(levelname)-8s %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

user=db_credentials['username']
dbpassword=db_credentials['password']
host=db_credentials['host']


def get_alerts_history(account_id):
    database=f'alerts'
    con = pymysql.connect(database=database, user=user, password=dbpassword, host=host)
   
    logger.info(f"Database {database} opened successfully")
    tableName=f"ALERTS_{account_id}"
    try:
        with con.cursor() as cur:
            sql = f"CREATE TABLE IF NOT EXISTS {tableName} (" \
                    f"timeStamp DATETIME," \
                    f"name VARCHAR(100), description VARCHAR(100), resourceId VARCHAR(100), service VARCHAR(100), region VARCHAR(100), linkedAccount VARCHAR(100), instanceType VARCHAR(100), alertType VARCHAR(100)," \
                    f"granularity VARCHAR(100), threshold VARCHAR(100)," \
                    f"cost VARCHAR(100), forecastedCost VARCHAR(100), apiOperation JSON, usageType JSON, email JSON, slackChannel VARCHAR(100), accountId VARCHAR(100), PRIMARY KEY (timeStamp,accountId,name))"
            cur.execute(sql)
            sql=f'select * from {tableName}'
            cur.execute(sql)
            result = cur.fetchall()
            if len(result):
                r = [dict((cur.description[i][0], value) \
                    for i, value in enumerate(row)) for row in result]
                return r
            else:
                ##added empty response @raj
                return Response(response={"response":[]},status=200,mimetype='application/json')

    except Exception as e:
            logger.error(str(traceback.format_exc(e)))
            return Response(status=500)


   
