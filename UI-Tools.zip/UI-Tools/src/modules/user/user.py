import pymysql
from src.modules.db import DB
from src.modules.s3_bucket import Bucket
from src.modules.cur import cur
from src.modules.session import Session
from config import tables, logger, user
from credentials import db_credentials

class User(Bucket):
    def __init__(self, name: str, email: str = None, role_arn: str = None, time_zone: str = None, company_name: str = None):
        self.name = name
        self.email = email
        self.role_arn = role_arn
        self.time_zone = time_zone
        self.company_name = company_name

        super().__init__(self.role_arn)

    def get_master_account_id(self, session):
        """
        Fetches master account id.
        """
        acccount_id = self.role_arn.split(':')[4]
        org_client = session.client('organizations')
        try:
            response = org_client.describe_organization()
            master_account_id = response['Organization']['MasterAccountId']
        except:
            master_account_id = acccount_id
        return master_account_id

    def create_linked_map(self,master_account_id,account_id):
        """
        Create organisation mapping for linked accounts.
        """

        user=db_credentials["username"]
        password=db_credentials["password"]
        host=db_credentials["host"]
        database=db_credentials["name"]
        print(master_account_id,account_id)
        try:
            con = pymysql.connect(database=database, user=user, password=password, host=host)
            cur = con.cursor()
            create_db_query = f"CREATE DATABASE IF NOT EXISTS master_{master_account_id}"
            print(create_db_query)
            cur.execute(create_db_query)
            con.commit()
            con.close()
            
            db_name = f"master_{master_account_id}"
            con = pymysql.connect(database=db_name, user=user, password=password, host=host)
            cur = con.cursor()
            
            create_table_query = f"CREATE TABLE IF NOT EXISTS organisation (master_account varchar(255), linked_account varchar(255))"
            print(create_table_query)
            cur.execute(create_table_query)
            
            insert_query = f"INSERT INTO organisation(master_account, linked_account) VALUES('{master_account_id}','{account_id}')"

            cur.execute(insert_query)
            con.commit()
            con.close()
            return True
        except Exception as e:
            return str(e)

    def store_info(self, master_account_id, account_id) -> bool:
        """
        Stores user info in dynamodb table.

        :return: True/False for success/failure
        """

        self.create_linked_map(master_account_id,account_id)
        db = DB()
        item = {
            "primaryKey": "accountId",
            "attributes": {
                "accountId": {
                    "Value": account_id,
                    "Type": 'S'
                },
                "name": {
                    "Value": self.name,
                    "Type": 'S'
                },
                "emailId": {
                    "Value": self.email,
                    "Type": 'S'
                },
                "srcBucket": {
                    "Value": f"opslyft-{master_account_id}-cur-bucket",
                    "Type": 'S'
                },
                "destBucket": {
                    "Value": f"{master_account_id}-cur-bucket",
                    "Type": 'S'
                },
                "timeZone": {
                    "Value": self.time_zone,
                    "Type": 'S'
                },
                "companyName": {
                    "Value": self.company_name,
                    "Type": 'S'
                }
            }
        }

        logger.info("Storing user info")
        return db.update_item(item=item, table_name=tables["user"])

    @staticmethod
    def get_role_arn(email: str) -> bool or str:
        """
        Gets the user with the specified email. Returns False if user does not exists.

        :param email: The email of the user
        :return: bool or dict
        """

        db = DB()

        item = {
            "Key": "email",
            "Value": email,
            "Type": 'S'
        }

        logger.info("Getting user info")
        res = db.get_item(item=item, table_name=tables["user"])

        if not res:
            logger.error("User does not exist")
            return res

        role_arn = res["roleArn"]['S']
        return role_arn

    def get_buckets(self, account_id):
        """
        Gets the user with the specified account Id. Returns False if user does not exists.

        :param account_id: The account Id of the user
        :return: bool or str
        """
        db = DB()

        item = {
            "Key": "accountId",
            "Value": account_id,
            "Type": 'S'
        }

        logger.info("Getting user info")
        res = db.get_item(item=item, table_name=tables["user"])

        if not res:
            logger.error("User does not exist")
            return res
        
        src_bucket = res["srcBucket"]["S"]
        dest_bucket = res["destBucket"]["S"]
        return src_bucket, dest_bucket

    def integrate_acc(self) -> bool:
        """
        Calls the above functions and integrates user's AWS account with OpsLyft.

        :return: True/False for success/failure
        """

        session_obj = Session()
        session_obj.session = self.role_arn
        session = session_obj.session
        account_id = self.role_arn.split(':')[4]

        master_account_id = self.get_master_account_id(session)
        

        if self.company_name.lower() == "niki":
            # Fetching bucket list for niki implementation
            s3 = session.resource('s3')
            if s3.Bucket(f'opslyft-{master_account_id}-cur-bucket') in s3.buckets.all() == True:
                stored = self.store_info(master_account_id, account_id)
                src_bucket,dest_bucket = self.get_buckets(account_id)
                created = self.create_buckets(session=session, bucket_name=src_bucket, company_name=self.company_name)
                return stored and created

            else:
                stored = self.store_info(master_account_id, account_id)
                return stored
        
        else:
            if master_account_id == account_id:
                stored = self.store_info(master_account_id, account_id)
                src_bucket,dest_bucket = self.get_buckets(account_id)
                created = self.create_buckets(session=session, bucket_name=src_bucket, company_name=self.company_name)
                enabled = cur.enable_cur(session=session, report_name=user["cur_report_name"], bucket_name=src_bucket)
                return stored and created and enabled
            else:
                stored = self.store_info(master_account_id, account_id)
                return stored
