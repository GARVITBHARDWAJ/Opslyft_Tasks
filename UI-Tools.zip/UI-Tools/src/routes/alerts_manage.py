import re
from flask import Response,Blueprint, g
from flask import request
from config import logger
from src.modules.alerts.getRules import get_rules
from src.modules.alerts.getHistory import get_alerts_history
from src.modules.alerts.deploy import deploy
from src.modules.alerts.delete import delete
from src.modules.alerts.authentication import validate_login
import json

alert_manager = Blueprint(__name__, "alerts",url_prefix='/alerts_manager')

@alert_manager.before_request
def before_request():
    if request.method == 'OPTIONS':
        return Response(status=200)
    reqBody = request.get_json()
    if 'AccessToken' in reqBody:
        accessToken = reqBody['AccessToken']
    else:
        return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')
    try:
        validate = validate_login(accessToken)['body']
        g.accountId = validate['account_id']
    except Exception as e:
        logger.error(str(e))
        return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')


@alert_manager.route("/get_rules", methods=["POST"])
def hget_rules() -> Response:
    reqBody = request.get_json()
    if 'admin' in reqBody:
        accountId = reqBody['accountId']
    else:
        accountId = g.accountId
    res = get_rules(accountId)
    if res: 
        return res
    return Response(status=500)

@alert_manager.route("/get_history", methods=["POST"])
def hget_history() -> Response:
    reqBody = request.get_json()
    if 'admin' in reqBody:
        accountId = reqBody['accountId']
    else:
        accountId = g.accountId

    res = get_alerts_history(accountId)
    if res:
        return json.dumps(res, default=str)
    return Response(status=500)

@alert_manager.route("/deploy_rules", methods=["POST"])
def hdeploy() -> Response:
    reqBody = request.get_json()
    accountId = g.accountId
    body = reqBody['body']
    res = deploy(accountId , body)
    if res: 
        return Response(status=200)
    return Response(status=500)



@alert_manager.route("/delete_rules", methods=["POST"])
def hdelete() -> Response:
    reqBody = request.get_json()
    accountId = g.accountId
    res = delete(accountId, reqBody)
    if res: 
        return Response(status=200)
    return Response(status=500)


# if __name__ == "__main__":
#     app.run("localhost", port=5000)
