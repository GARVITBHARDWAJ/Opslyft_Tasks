from flask import Flask,request,Response,Blueprint,g
from config import logger
import json
import pymysql
import os
from credentials import db_credentials
from src.modules.alerts.authentication import validate_login
from src.modules.home import weeklyCost, dailyCost,lastMonthCost, monthToDateCost,forcastedCost, homeIrm
from src.modules.alerts.filterCostTrends import filteredCost
# from flask_cors import CORS
#-------------New-----------
from utils.getAwsSession import awsSession
from src.modules.home import get_month_to_date_bill, get_prev_month_bill, get_month_forecast_bill
import boto3
#---------------------------
user=db_credentials['username']
dbpassword=db_credentials['password']
host=db_credentials['host']

# app = Flask(__name__)
# CORS(app)
home_handler = Blueprint(__name__, "home",url_prefix='/home')

@home_handler.before_request
def before_request():
    if request.method == 'OPTIONS':
        return Response(status=200)
    reqBody = request.get_json()
    if 'AccessToken' in reqBody:
        accessToken = reqBody['AccessToken']
    else:
        return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')
    try:
        validate = validate_login(accessToken)['body']
        g.accountId = validate['account_id']
    except Exception as e:
        logger.error(str(e))
        return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')


# #-------------- fetching total cost of yesterday and last week from reports table-----
@home_handler.route('/reports',methods=['POST'])
def reports():
    reqBody = request.get_json()
    if 'admin' in reqBody:
        accountId = reqBody['accountId']
    else:    
        accountId = g.accountId
    response = dict()
    response['yesterday']=dailyCost(accountId=accountId)
    response['LastWeek'] = weeklyCost(accountId=accountId)

    return Response(json.dumps(response),status=200,mimetype='application/json')

@home_handler.route('/trends',methods=['POST'])
def trends():
    reqBody = request.get_json()
    accountId = g.accountId
    response = dict()
    response['lastMonthCost']= lastMonthCost(accountId=accountId)
    response['monthToDateCost']= monthToDateCost(accountId=accountId)
    response['forcastedCost']= forcastedCost(accountId=accountId,cost=response['monthToDateCost'])


    return Response(json.dumps(response),status=200,mimetype='application/json')


@home_handler.route('/irm', methods = ['POST'])
def irmFunc():
    accountId = g.accountId
    response = dict()
    response = homeIrm(accountId=accountId)

    return Response(json.dumps(response),status=200,mimetype='application/json')

@home_handler.route('/ce_cost_trends', methods = ['POST'])
def get_ce_cost():
    result = dict()
    arn = ""
    accountId = g.accountId
    arn = f"arn:aws:iam::{accountId}:role/OpsLyftFetchUsageMetricsRole"   

    try:
        session = awsSession(arn)
        client = session.client('ce')
        month_to_date = get_month_to_date_bill(client)
        past_month = get_prev_month_bill(client)
        month_forecast = get_month_forecast_bill(client)
        result.update(month_to_date)
        result.update(past_month)
        result.update(month_forecast)
    except Exception as e:
        logger.error(str(e))
     
    return Response(json.dumps(result),status=200,mimetype='application/json')

@home_handler.route('/filter_cost_trends', methods = ['POST'])
def filterCostTrends():
    filter = dict()
    reqBody = request.get_json()
    accountId = g.accountId
    filter = reqBody['filters']
    response = dict()
    response = filteredCost(accountId=accountId,filter=filter)

    return Response(json.dumps(response),status=200,mimetype='application/json')
