from flask import Flask, request, Response, Blueprint
from config import logger
import os, boto3,traceback, json
from flask_cors import CORS

admin_access = Blueprint(__name__,"admin", url_prefix="/admin")
@admin_access.route('/list', methods=['POST'])
def admin():
    try:
        dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
        logger.info("connected to database successfully")
        table = dynamodb.Table('user-info')
        data = table.scan()
        logger.info("Table scanned")
        d = dict()
        for i in data['Items']:
            accountId = i['accountId'].split('-')[0]
            d[i['companyName']] = accountId
        return d

    except Exception as e:
        return str(e)