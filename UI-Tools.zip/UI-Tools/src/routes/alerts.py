from flask import request,Response,Blueprint,g
from flask import current_app as app
from config import logger
from flask_mail import Mail, Message
import traceback
import boto3
import json
import pymysql
import os
from credentials import db_credentials
from src.modules.alerts.authentication import validate_login
# from flask_cors import CORS

user=db_credentials['username']
dbpassword=db_credentials['password']
host=db_credentials['host']

sender_email = "Aayush@opslyft.com"
password = "InnoOpsLyft@123"

# app = Flask(__name__)
# CORS(app)
alert_handler = Blueprint(__name__, "alerts",url_prefix='/alerts')

@alert_handler.before_request
def before_request():
    if request.method == 'OPTIONS':
        return Response(status=200)
    reqBody = request.get_json()
    if 'AccessToken' in reqBody:
        accessToken = reqBody['AccessToken']
    else:
        return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')
    try:
        validate = validate_login(accessToken)['body']
        g.accountId = validate['account_id']
    except Exception as e:
        logger.error(str(e))
        return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')



def getService(cur,accountId):
    flatList = []
    try:
        print("Database opened successfully")
        tableName=f"MasterCur{accountId}"
        sql=f'select distinct lineItemProductCode from {tableName}'
        cur.execute(sql)
        result=cur.fetchall()
        for subtuple in result:
            for item in subtuple:
                flatList.append(item)
    except:
        print(traceback.format_exc())
    return flatList 

def instanceType(cur,accountId):
    flatList = []
    try:
        print("Database opened successfully")
        tableName=f"MasterCur{accountId}"
        sql=f'select distinct productinstanceType from {tableName}'
        cur.execute(sql)
        result=cur.fetchall()
        for subtuple in result:
            for item in subtuple:
                flatList.append(item)
    except:
        print(traceback.format_exc())
    return flatList

# def resourceID(cur,accountId):
#     flatList = []
#     try:
#         print("Database opened successfully")
#         tableName=f"MasterCur{accountId}"
#         sql=f'select distinct lineItemResourceId from {tableName}'
#         cur.execute(sql)
#         result=cur.fetchall()
#         for subtuple in result:
#             for item in subtuple:
#                 flatList.append(item)
#     except:
#         print(traceback.format_exc())
#     return flatList

def region(cur,accountId):
    flatList = []
    try:
        print("Database opened successfully")
        tableName=f"MasterCur{accountId}"
        sql=f'select distinct lineItemAvailabilityZone from {tableName}'
        cur.execute(sql)
        result=cur.fetchall()
        for subtuple in result:
            for item in subtuple:
                flatList.append(item)
    except:
        print(traceback.format_exc())
    return flatList

def linkedAccount(cur,accountId):
    flatList = []
    try:
        print("Database opened successfully")
        tableName=f"MasterCur{accountId}"
        sql=f'select distinct lineItemUsageAccountId from {tableName}'
        cur.execute(sql)
        result=cur.fetchall()
        for subtuple in result:
            for item in subtuple:
                flatList.append(item)
    except:
        print(traceback.format_exc())
    return flatList
def get_tag(cur,accountId):
    tagList = []
    try: 
        logger.info('database connect successfully')
        tableName = f"MasterCur{accountId}"
        sql = f"SELECT column_name FROM information_schema.columns WHERE table_name= '{tableName}' AND column_name LIKE 'Tag_%'"
        cur.execute(sql)
        result = cur.fetchall()
        logger.info("Get all tagName successfully")
        tagDict = {}
        for tag in result:
            try:
                sql = f"SELECT DISTINCT {tag[0]} FROM {tableName}"
                cur.execute(sql)
                result = cur.fetchall()
                flatList = []
                for subtuple in result:
                    for item in subtuple:
                        flatList.append(item)
                tagDict[tag[0]] = flatList
            except:
                continue
        return(tagDict) 
    except:
        print(traceback.format_exc())
    
    return tagDict


@alert_handler.route('/list_filters',methods=['POST'])
def show():
    accountId = g.accountId
    #accountId = reqBody['accountId']
    database=f'master_{accountId}'
    con = pymysql.connect(database=database, user=user, password = dbpassword, host=host)
    with con.cursor() as cur:
        service=getService(cur,accountId)
        linkedAcc = linkedAccount(cur,accountId)
        reg = region(cur,accountId)
        # res = resourceID(cur,accountId)
        insTyp = instanceType(cur,accountId)
        getTag = get_tag(cur,accountId)
    con.commit()
    con.close()    

    response={'service':service, 'LinkedAccount' : linkedAcc, 'Region' : reg, 'InstanceType' : insTyp, 'Tag': getTag}

    return Response(json.dumps(response),status=200,mimetype='application/json')
