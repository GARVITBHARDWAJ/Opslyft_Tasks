from flask import Flask,request,Response,render_template,Blueprint, g
from flask import current_app as app
from config import logger
from flask_mail import Mail, Message
import traceback
import boto3
import json
import pymysql
import os
from credentials import db_credentials
from src.modules.alerts.authentication import validate_login
from src.modules.reports.gcpReports import deployConfig,listConfig,updateConfig,deleteConfig,deleteGCPStoredReport,shareGCPStoredReport
# from src.modules.costs import weeklyCost, dailyCost 
# from flask_cors import CORS

user=db_credentials['username']
dbpassword=db_credentials['password']
host=db_credentials['host']

sender_email = "Aayush@opslyft.com"
password = "InnoOpsLyft@123"

# app = Flask(__name__)
# CORS(app)
report_handler = Blueprint(__name__, "reports",url_prefix='/reports')

@report_handler.before_request
def before_request():
    if request.method == 'OPTIONS':
        return Response(status=200)
    reqBody = request.get_json()
    if 'AccessToken' in reqBody:
        accessToken = reqBody['AccessToken']
    else:
        return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')
    try:
        validate = validate_login(accessToken)['body']
        g.accountId = validate['account_id']
    except Exception as e:
        logger.error(str(e))
        return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')
        
def queryReports(accountId):
    database='reports'
    reports=[]
    try:
        con = pymysql.connect(database=database, user=user, password=dbpassword, host=host)
        print("Database opened successfully")
        tableName=f"reports{accountId}"
        with con.cursor() as cur:
            sql=f'select * from {tableName}'
            cur.execute(sql)
            result=cur.fetchall()
            if result:
                for i in result:
                    report={'viewUrl':i[0],'accountId':i[1],'subject':i[2],'sent':i[3],'date':str(i[4]),'type':i[5], 'totalCost':i[6]}
                    reports.append(report)

    except:
        print(traceback.format_exc())
    finally:
        con.close()
    return reports


def deleteReport(accountId,url):

    database='reports'
    try:
        con = pymysql.connect(database=database, user=user, password=dbpassword, host=host)
        print("Database opened successfully")
        tableName=f"reports{accountId}"
        with con.cursor() as cur:
            sql=f"delete from {tableName} where url='{url}'"
            cur.execute(sql)
    except:
        print(traceback.format_exc())
    finally:
        con.commit()
        con.close()
    return True


def shareReport(emails,key,subject):

    mail_settings = {
        "MAIL_SERVER": 'smtp.gmail.com',
        "MAIL_PORT": 465,
        "MAIL_USE_TLS": False,
        "MAIL_USE_SSL": True,
        "MAIL_USERNAME": sender_email,
        "MAIL_PASSWORD": password
    }

    app.config.update(mail_settings)
    mail = Mail(app)

    try:

        with app.app_context():
            msg = Message(subject=subject,
                          sender="noreply@opslyft.com",
                          recipients=emails)

            msg.html=render_template(key)
            mail.send(msg)
            print("here")
            os.remove(f'templates/{key}')
    except:
        print(traceback.format_exc())
        return False
    return True

@report_handler.route('/list',methods=['POST'])
def show():
    reqBody = request.get_json()
    if 'admin' in reqBody:
        accountId = reqBody['accountId']
    else:
        accountId = g.accountId
    response=queryReports(accountId)
    response={'response':response}
    return Response(json.dumps(response),status=200,mimetype='application/json')


@report_handler.route('/delete',methods=['POST'])
def delete():
    reqBody = request.get_json()
    accountId = g.accountId
    data=reqBody['data']
    s3=boto3.client('s3')
    resp=False
    for emailToDelete in data:
        url=emailToDelete['viewURL']
        key=url.split('/')[3]
    
        resp=s3.delete_object(Bucket=f'opslyft-{accountId}-reports',Key=key)
        logger.info(f"Deleted {url}")
        deleteReport(accountId,url)

    if resp:
        response=queryReports(accountId)
        response={'response':response}
        return Response(json.dumps(response),status=200,mimetype='application/json')
    else:
        return Response('Some Error occured',status=500)


@report_handler.route('/share',methods=['POST'])
def share():
    reqBody = request.get_json()
    accountId = g.accountId
    emails=reqBody['emails']
    data=reqBody['data']
    
    
    s3=boto3.client('s3')
    # url,subject='',''
    for emailToShare in data:
        shareStatus=False
        url=emailToShare['viewURL']
        subject=emailToShare['subject']
        
        key=url.split('/')[3]
        s3.download_file(f'opslyft-{accountId}-reports',key,f'templates/{key}')

        shareStatus=shareReport(emails,key,subject)
        if shareStatus:
            logger.info(f"Shared {url} to {emails}")
    if shareStatus:
        return Response('Shared',status=200)
    else:
        return Response('Some Error occured',status=500)

@report_handler.route('/gcp_deploy',methods=['POST'])
def store():
    primaryEmail = g.accountId
    body = request.get_json()['body']
    res = deployConfig(body,primaryEmail)
    return Response(res[0],status=res[1])

@report_handler.route('/gcp_list',methods=['POST'])
def list():
    primaryEmail = g.accountId
    # body = request.get_json()['body']
    #period = request.get_json()['period']
    res = listConfig(primaryEmail)
    return Response(json.dumps(res[0]),status=res[1],mimetype='application/json')

@report_handler.route('/gcp_update',methods=['POST'])
def update():
    primaryEmail = g.accountId
    body = request.get_json()['body']
    res = updateConfig(body,primaryEmail)
    return Response(res[0],status=res[1])

@report_handler.route('/gcp_delete',methods=['POST'])
def deletefunc():
    primaryEmail = g.accountId
    name = request.get_json()['name']
    res = deleteConfig(name,primaryEmail)
    return Response(res[0],status=res[1])

@report_handler.route('/gcp_report_delete',methods=['POST'])
def gpcReportDeletefunc():
    primaryEmail = g.accountId
    # primaryEmail = 'manish@inshorts.com'
    reqBody = request.get_json()
    data=reqBody['data']
    resp=deleteGCPStoredReport(primaryEmail,data)

    if resp:
        return Response('Reports Deleted',status=200)
    else:
        return Response('Some Error occured',status=500)

@report_handler.route('/gcp_report_share',methods=['POST'])
def gpcReportSharefunc():
    primaryEmail = g.accountId
    reqBody = request.get_json()
    data=reqBody['data']
    emails=reqBody['emails']
    resp=shareGCPStoredReport(primaryEmail,data,emails)

    if resp:
        return Response('Reports Sent',status=200)
    else:
        return Response('Some Error occured',status=500)