from flask import Flask,request,Response,Blueprint,g
from config import logger
import json
import os
from src.modules.settings.SettingPageBackend import find_all_ids
from src.modules.alerts.authentication import validate_login
settingPage = Blueprint(__name__, "settings",url_prefix='/settings')

@settingPage.before_request
def before_request():
    if request.method == 'OPTIONS':
        return Response(status=200)
    reqBody = request.get_json()
    if 'AccessToken' in reqBody:
        accessToken = reqBody['AccessToken']
    else:
        return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')
    try:
        validate = validate_login(accessToken)['body']
        g.accountId = validate['account_id']
    except Exception as e:
        logger.error(str(e))
        return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')

# def before_request():
#     reqBody = request.get_json()
#     if 'AccessToken' in reqBody:
#         accessToken = reqBody['AccessToken']
#     else:
#         return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')
#     try:
#         validate = validate_login(accessToken)['body']
#         g.accountId = validate['account_id']
#     except Exception as e:
#         logger.error(str(e))
#         return Response(json.dumps({"response":"Token expired or invalid token"}),status=401,mimetype='application/json')


@settingPage.route('/linked_accounts', methods=['POST'])
def Linked_accounts():
    reqBody = request.get_json()
    if 'admin' in reqBody:
        accountId = reqBody['accountId']
    else:
        accountId = g.accountId
    response = find_all_ids(accountId)
    return Response(json.dumps(response),status=200,mimetype='application/json')

