for PROJECT in {projectList}
do

gcloud services enable cloudresourcemanager.googleapis.com --project=$PROJECT
gcloud services enable cloudasset.googleapis.com --project=$PROJECT
gcloud services enable iam.googleapis.com --project=$PROJECT

wget https://opslyft-gcp-script.s3.amazonaws.com/opslyft_$PROJECT\_Access.yaml

gcloud iam roles create opslyft_enhanced_monitoring_{randomSuffix} \
 --project=$PROJECT --file=opslyft_$PROJECT\_Access.yaml

 gcloud projects add-iam-policy-binding $PROJECT \
 --member serviceAccount:opslyft@rock-bonus-299515.iam.gserviceaccount.com \
 --role "projects/$PROJECT/roles/opslyft_enhanced_monitoring_{randomSuffix}"
done
