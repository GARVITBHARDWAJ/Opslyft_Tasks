gcloud iam roles create opslyft_billing_{randomSuffix} --project {billing_project_id} --title "opslyft Billing Role" --description "Allows opslyft access to billing account data" --permissions bigquery.jobs.create,bigquery.tables.getData

gcloud projects add-iam-policy-binding {billing_project_id} --member serviceAccount:opslyft@rock-bonus-299515.iam.gserviceaccount.com --role 'projects/{billing_project_id}/roles/opslyft_billing_{randomSuffix}'

gsutil mb -p {billing_project_id} -l us-east1 -b on gs://opslyft-{billing_project_id}

gsutil iam ch serviceAccount:opslyft@rock-bonus-299515.iam.gserviceaccount.com:roles/storage.admin gs://opslyft-{billing_project_id}

gcloud projects list --format=json > project_list.json

gcloud projects list --format="table(project_id)" |tail -n +2| while read -r PROJECT; do gcloud services list --format="table("name")" --project=$PROJECT | awk '{{split($0,a,"/"); print a[4]}}' | awk '{{split($0,a,"."); print a[1]}}' > $PROJECT.json ;done

zip opslyft *.json