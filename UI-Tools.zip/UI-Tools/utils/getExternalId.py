from src.modules.db import DB

tables = {
    "user": "user-info"
}


def getExternalId(accountId):
    """
    Fetches external id for the role.
    """
    db = DB()
    item = {
        "Key": "accountId",
        "Value": accountId,
        "Type": "S"
    }

    res = db.get_item(item=item, table_name=tables['user'])
    if not res:
        return res
    externalId = res["externalId"]["S"]
    # master_account_id = dest_bucket.split("-")[0]
    return externalId