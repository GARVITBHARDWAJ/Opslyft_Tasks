
import boto3
from utils.getExternalId import getExternalId
from config import logger
def awsSession(arn):
    """
    Creates session for the assigned role
    """
    client = boto3.client("sts")
    accountId=arn.split(':')[4]
    externalId=getExternalId(accountId)
    response = client.assume_role(
        RoleArn=arn, RoleSessionName="opslyft-session", ExternalId=externalId)
    session = boto3.Session(
        aws_access_key_id=response['Credentials']['AccessKeyId'],
        aws_secret_access_key=response['Credentials']['SecretAccessKey'],
        aws_session_token=response['Credentials']['SessionToken']
    )
    logger.info('assumed role')
    return session