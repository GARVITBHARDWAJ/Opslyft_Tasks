from flask import Flask,request
from flask_mail import Mail, Message
from credentials import sender_email,password
import traceback
from config import logger


app = Flask(__name__)
app.jinja_env.globals.update(zip=zip)
mail_settings = {
    "MAIL_SERVER": 'smtp.gmail.com',
    "MAIL_PORT": 465,
    "MAIL_USE_TLS": False,
    "MAIL_USE_SSL": True,
    "MAIL_USERNAME": sender_email,
    "MAIL_PASSWORD": password
}

app.config.update(mail_settings)
mail = Mail(app)

@app.route('/sendMail',methods=['POST'])
def sendMail():
    reqBody = request.get_json()
    reportName=reqBody['reportName']
    emails=reqBody['emails']
    csvName=reqBody['csvName']
    try:
        with app.app_context():
            subject=f"Your {reportName} report is Here"
            message=f"Your auto-generated report from Opslyft for report name {reportName} is attached"
            msg = Message(subject=subject,
                            body=message,
                            sender="noreply@opslyft.com",
                            recipients=emails)
            with app.open_resource(f"csvs/{csvName}") as fp:
                msg.attach(csvName, "text/csv", fp.read())
            mail.send(msg)

            return {"status":True}
    except Exception as e:
        logger.error('Error Sending mail:' +str(traceback.format_exc()))
        return {"status":False}
if __name__ == "__main__":
    app.run(host="localhost",port=2000, debug=True, threaded=True)
