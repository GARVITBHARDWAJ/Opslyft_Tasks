import logging

logging.basicConfig(
    format="[%(asctime)s] %(levelname)s [%(name)s.%(funcName)s:%(lineno)d] %(message)s",
    filename="logs.log",
    filemode='w',
)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

mailUrl='http://127.0.0.1:2000/sendMail'
tables = {
    "user": "user-info",
    "gcpUser": "gcp-user-info"
}
user = {
    "cur_bucket_name": "opslyft-cur-bucket",
    "cur_report_name": "opslyft-cur-report"
}

gcpDetailsTable='gcp-user-info'