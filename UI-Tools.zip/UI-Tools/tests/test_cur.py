import unittest
import sys

sys.path.append("../")

from config import test_rolearn
from src.modules.cur import enable_cur
from src.modules.session import Session


class MyTestCase(unittest.TestCase):
    def test_something(self):
        session_obj = Session()
        session_obj.session = test_rolearn
        session = session_obj.session

        res = enable_cur(session=session, report_name="test_cur_report", bucket_name="opslyft-cur-bucket")
        self.assertEqual(res, True)


if __name__ == '__main__':
    unittest.main()
