import unittest
import sys

sys.path.append("../")

from config import test_rolearn
from src.modules.session import Session
from src.modules.s3_bucket import Bucket

class TestS3Bucket(unittest.TestCase):
    def test_s3Bucket(self):
        session_obj = Session()
        session_obj.session = test_rolearn
        session = session_obj.session

        bucket = Bucket(role_arn=test_rolearn)
        res = bucket.create_buckets(session=session, bucket_name="opslyft-cur-bucket")

        self.assertEqual(res, True)


if __name__ == '__main__':
    unittest.main()
