import unittest
import sys

sys.path.append("../")

from src.modules.db import DB


class TestDb(unittest.TestCase):
    def test_createTable(self):
        table_name = "test_table"
        primary_key = "test_key"
        primary_key_type = 'S'

        res = DB().create_table(primary_key=primary_key, primary_key_type=primary_key_type, table_name=table_name)

        self.assertEqual(res, False)

    def test_putItem(self):
        table_name = "test_table"
        primary_key = "test_key"

        item = {
            "primaryKey": primary_key,
            "attributes": {
                primary_key: {
                    "Value": "test_value",
                    "Type": 'S'
                }
            }
        }

        res = DB().put_item(item=item, table_name=table_name)
        self.assertEqual(res, False)

    def test_getItem(self):
        table_name = "test_table"
        item_present = {
            "Key": "test_key",
            "Value": "test_value",
            "Type": 'S'
        }
        item_not_present = {
            "Key": "test_key",
            "Value": "test_value_1",
            "Type": 'S'
        }

        res1 = DB().get_item(item=item_present, table_name=table_name)
        res2 = DB().get_item(item=item_not_present, table_name=table_name)

        self.assertEqual(res1["test_key"]['S'], "test_value")
        self.assertEqual(res2, False)

    def test_updateItem(self):
        table_name = "test_table"
        primary_key = "test_key"

        item = {
            "primaryKey": primary_key,
            "attributes": {
                primary_key: {
                    "Value": "test_value",
                    "Type": 'S'
                },
                "newKey": {
                    "Value": "updated_value",
                    "Type": 'S'
                }
            }
        }

        res = DB().update_item(item=item, table_name=table_name)

        self.assertEqual(res, True)


if __name__ == '__main__':
    unittest.main()
